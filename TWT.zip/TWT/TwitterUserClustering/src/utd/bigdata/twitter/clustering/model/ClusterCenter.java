package utd.bigdata.twitter.clustering.model;

public class ClusterCenter {
	private int iCenter;
	private int iClusterIndex;

	public int getiCenter() {
		return iCenter;
	}

	public void setiCenter(int iCenter) {
		this.iCenter = iCenter;
	}

	public int getiClusterIndex() {
		return iClusterIndex;
	}

	public void setiClusterIndex(int iClusterIndex) {
		this.iClusterIndex = iClusterIndex;
	}

}
